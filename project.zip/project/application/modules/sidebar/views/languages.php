<ul class="dropdown-menu text-left">
            <li><a href="<?=base_url()?>set_language?lang=english" title="English">
            	<img src="<?=base_url()?>resource/images/flags/us.gif" alt="English"  /> English
            	</a>
            </li>

            <li> <a href="<?=base_url()?>set_language?lang=spanish" title="Spanish">
            	<img src="<?=base_url()?>resource/images/flags/es.gif" alt="Spanish"  /> Spanish
            	</a> 
            </li>
             <li> <a href="<?=base_url()?>set_language?lang=german" title="German">
            	<img src="<?=base_url()?>resource/images/flags/de.gif" alt="German"  /> German
            	</a> 
            </li>

            <li> <a href="<?=base_url()?>set_language?lang=french" title="French">
            	<img src="<?=base_url()?>resource/images/flags/fr.gif" alt="French"  /> French
            	</a> 
            </li>

             <li> <a href="<?=base_url()?>set_language?lang=portuguese" title="Portuguese">
            	<img src="<?=base_url()?>resource/images/flags/pt.gif" alt="Portuguese"  /> Portuguese
            	</a> 
            </li>

             <li> <a href="<?=base_url()?>set_language?lang=norwegian" title="Norwegian">
            	<img src="<?=base_url()?>resource/images/flags/no.gif" alt="Norwegian"  /> Norwegian
            	</a> 
            </li>

            <li> <a href="<?=base_url()?>set_language?lang=dutch" title="Dutch">
            	<img src="<?=base_url()?>resource/images/flags/nl.gif" alt="Dutch"  /> Dutch
            	</a> 
            </li>

            <li> <a href="<?=base_url()?>set_language?lang=czech" title="Czech">
                <img src="<?=base_url()?>resource/images/flags/cz.gif" alt="Czech"  /> Czech
                </a> 
            </li>
            <li> <a href="<?=base_url()?>set_language?lang=romanian" title="Romanian">
                <img src="<?=base_url()?>resource/images/flags/ro.gif" alt="Romanian" /> Romanian
				</a>
			</li>
			<li> <a href="<?=base_url()?>set_language?lang=greek" title="Greek">
				<img src="<?=base_url()?>resource/images/flags/gr.gif" alt="Greek"  /> Greek
                </a> 
            </li>
            
          </ul>