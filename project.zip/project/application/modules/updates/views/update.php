<section id="content">
  <section class="hbox stretch">
    <aside>
      <section class="vbox">
        <section class="scrollable padder">
            <ul class="breadcrumb no-border no-radius b-b b-light pull-in">
    <li><a href="<?=base_url()?>"><i class="fa fa-home"></i> <?=lang('home')?></a></li>
    <li class="active"><?=lang('updates')?></li>
            </ul>
   <div class="row padder">
          <section class="panel panel-default">
            <header class="panel-heading"><?=lang('system_details')?></header>
            <section class="panel-body">
            <div class="row">
              <div class="col-lg-6">
                <ul class="list-group no-radius">
                  <li class="list-group-item"><span class="pull-right"><?=config_item('version')?><?=config_item('build') > 0 ? " build ".config_item('build') : ""?></span><?=lang('fo_version')?></li>
                  <li class="list-group-item"><span class="pull-right"><?=phpversion()?></span><?=lang('php_version')?></li>
                  <li class="list-group-item"><span class="pull-right"><?=CI_VERSION?></span><?=lang('ci_version')?></li>
                </ul>
              </div>
              <div class="col-lg-6">
                <ul class="list-group no-radius">
                    <?php $status = Applib::pc(); ?>
                    <?php $beta = config_item("beta_updates") == "TRUE" ? TRUE : FALSE; ?>
                  <li class="list-group-item"><span class="pull-right badge bg-<?=$status == 'validated' ? 'success' : 'danger'?>"><?=lang($status)?></span>Nulled by Voky
</li>
                 
                  
                </ul>
              </div>
            </div>
            </section>
            </section>

      
        <section class="panel panel-default">
        <header class="panel-heading">
            <a href="<?=base_url()?>updates/backup/" class="btn btn-info btn-xs pull-right"><?=lang('backup_now')?></a>
            <?=lang('backups')?></header>
                <div class="table-responsive">
                  <table id="table-clients" class="table table-striped m-b-none">
                    <tbody>
                    <?php foreach ($backups as $file) : ?>
                        <tr>
                        <td><a href="<?=base_url()?>resource/backup/<?=$file?>" class="text-info"><?=$file?></a></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (count($backups) == 0) : ?>
                        <tr><td><?=lang('no_backup_found')?></td></tr>
                    <?php endif; ?>
                  </tbody>
                </table>
                </div>
        </section>
<!-- footer -->
<?php if (config_item('hide_branding') == 'FALSE') : ?>
  <footer id="footer">
    <div class="text-center padder clearfix">
      <p>
        
      </p>
    </div>
  </footer>
<?php endif; ?>
  <!-- / footer -->
  
</div>
</section>
</section>
    </aside>
<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
</section>
</section>