<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-30 20:37:04 --> Could not find the language line "Enter_the_code_exactly"
