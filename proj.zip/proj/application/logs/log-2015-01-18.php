<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-18 20:52:17 --> 404 Page Not Found --> errors/error_404
