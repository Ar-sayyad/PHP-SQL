<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-20 04:23:23 --> Could not find the language line "Enter_the_code_exactly"
