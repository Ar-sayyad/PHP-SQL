<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-03 07:38:28 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-03 07:38:28 --> Unable to connect to the database
ERROR - 2015-04-03 07:38:59 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-03 07:38:59 --> Unable to connect to the database
ERROR - 2015-04-03 07:40:00 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-03 07:40:00 --> Unable to connect to the database
ERROR - 2015-04-03 07:41:00 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-03 07:41:00 --> Unable to connect to the database
ERROR - 2015-04-03 11:16:26 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-03 11:16:26 --> Unable to connect to the database
ERROR - 2015-04-03 20:16:41 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-03 20:16:41 --> Unable to connect to the database
