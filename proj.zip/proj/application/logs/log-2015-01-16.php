<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-16 21:15:11 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-16 21:53:59 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-16 22:00:58 --> De afbeelding die u probeert te oploaden is groter dan de maximum toegestande hoogte of breedte.
ERROR - 2015-01-16 22:01:29 --> Could not find the language line "Enter_the_code_exactly"
ERROR - 2015-01-16 22:02:26 --> Could not find the language line "Enter_the_code_exactly"
ERROR - 2015-01-16 22:02:43 --> Could not find the language line "Enter_the_code_exactly"
ERROR - 2015-01-16 22:03:00 --> Severity: Warning  --> fopen() [<a href='function.fopen'>function.fopen</a>]: open_basedir restriction in effect. File(/dev/urandom) is not within the allowed path(s): (/home/kevingx91/:/tmp:/var/tmp:/usr/local/lib/php/) /home/kevingx91/domains/kevinroelands.be/public_html/management/application/libraries/phpass-0.1/PasswordHash.php 49
ERROR - 2015-01-16 22:03:00 --> Severity: Warning  --> fopen(/dev/urandom) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: Operation not permitted /home/kevingx91/domains/kevinroelands.be/public_html/management/application/libraries/phpass-0.1/PasswordHash.php 49
ERROR - 2015-01-16 22:07:41 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-16 22:10:04 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-16 22:10:11 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-16 22:10:24 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-16 22:10:33 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-16 22:19:37 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-16 22:34:09 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-16 22:35:51 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-16 22:38:34 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-16 22:47:59 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-16 22:58:27 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-16 22:58:45 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-16 23:03:40 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-16 23:05:23 --> Severity: Warning  --> fopen() [<a href='function.fopen'>function.fopen</a>]: open_basedir restriction in effect. File(/dev/urandom) is not within the allowed path(s): (/home/kevingx91/:/tmp:/var/tmp:/usr/local/lib/php/) /home/kevingx91/domains/kevinroelands.be/public_html/client/application/libraries/phpass-0.1/PasswordHash.php 49
ERROR - 2015-01-16 23:05:23 --> Severity: Warning  --> fopen(/dev/urandom) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: Operation not permitted /home/kevingx91/domains/kevinroelands.be/public_html/client/application/libraries/phpass-0.1/PasswordHash.php 49
ERROR - 2015-01-16 23:07:14 --> Could not find the language line "other_details"
ERROR - 2015-01-16 23:07:21 --> Could not find the language line "other_details"
ERROR - 2015-01-16 23:11:18 --> Het bestandstype dat u probeert te uploaden is niet toegestaan.
ERROR - 2015-01-16 23:12:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/kevingx91/domains/kevinroelands.be/public_html/client/application/modules/projects/controllers/tasks.php 145
ERROR - 2015-01-16 23:12:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/kevingx91/domains/kevinroelands.be/public_html/client/application/modules/projects/controllers/tasks.php 438
ERROR - 2015-01-16 23:14:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/kevingx91/domains/kevinroelands.be/public_html/client/application/modules/projects/views/modal/edit_task.php 88
ERROR - 2015-01-16 23:14:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/kevingx91/domains/kevinroelands.be/public_html/client/application/modules/projects/controllers/tasks.php 73
ERROR - 2015-01-16 23:14:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/kevingx91/domains/kevinroelands.be/public_html/client/application/modules/projects/controllers/tasks.php 438
ERROR - 2015-01-16 23:14:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/kevingx91/domains/kevinroelands.be/public_html/client/application/modules/projects/views/group/sub_group/task.php 77
ERROR - 2015-01-16 23:15:08 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-16 23:16:00 --> Could not find the language line "other_details"
ERROR - 2015-01-16 23:16:08 --> Could not find the language line "other_details"
ERROR - 2015-01-16 23:16:13 --> Could not find the language line "other_details"
ERROR - 2015-01-16 23:21:15 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-16 23:22:09 --> Severity: Notice  --> Undefined variable: estimate_id /home/kevingx91/domains/kevinroelands.be/public_html/client/application/modules/estimates/controllers/estimates.php 273
ERROR - 2015-01-16 23:33:14 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-16 23:34:08 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-16 23:36:40 --> 404 Page Not Found --> errors/error_404
