<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-21 12:58:32 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-03-21 12:58:32 --> Unable to connect to the database
ERROR - 2015-03-21 12:58:41 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-03-21 12:58:41 --> Unable to connect to the database
ERROR - 2015-03-21 12:59:10 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-03-21 12:59:10 --> Unable to connect to the database
ERROR - 2015-03-21 15:25:29 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-03-21 15:25:29 --> Unable to connect to the database
