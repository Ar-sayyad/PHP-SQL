<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-29 08:15:17 --> Could not find the language line "Enter_the_code_exactly"
