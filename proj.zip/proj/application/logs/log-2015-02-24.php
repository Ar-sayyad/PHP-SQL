<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-24 16:25:42 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-02-24 16:26:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/kevingx91/domains/kevinroelands.be/public_html/management/application/modules/projects/views/group/sub_group/task.php 77
ERROR - 2015-02-24 16:27:22 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-02-24 16:27:58 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-02-24 16:28:21 --> 404 Page Not Found --> errors/error_404
