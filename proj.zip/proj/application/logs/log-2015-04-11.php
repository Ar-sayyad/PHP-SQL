<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-11 03:46:14 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-11 03:46:14 --> Unable to connect to the database
ERROR - 2015-04-11 03:46:38 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-11 03:46:38 --> Unable to connect to the database
ERROR - 2015-04-11 03:47:01 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-11 03:47:01 --> Unable to connect to the database
ERROR - 2015-04-11 03:47:38 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-11 03:47:38 --> Unable to connect to the database
ERROR - 2015-04-11 03:48:02 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-11 03:48:02 --> Unable to connect to the database
ERROR - 2015-04-11 03:48:39 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-11 03:48:39 --> Unable to connect to the database
ERROR - 2015-04-11 03:49:03 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-11 03:49:03 --> Unable to connect to the database
ERROR - 2015-04-11 06:41:56 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-11 06:41:56 --> Unable to connect to the database
