<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-28 22:07:42 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-02-28 22:09:14 --> 404 Page Not Found --> errors/error_404
