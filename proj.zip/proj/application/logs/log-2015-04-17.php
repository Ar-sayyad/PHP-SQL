<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-17 01:43:26 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-17 01:43:26 --> Unable to connect to the database
ERROR - 2015-04-17 08:41:34 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-17 08:41:34 --> Unable to connect to the database
ERROR - 2015-04-17 11:48:19 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-17 11:48:19 --> Unable to connect to the database
ERROR - 2015-04-17 14:38:21 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-17 14:38:21 --> Unable to connect to the database
ERROR - 2015-04-17 20:40:23 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-17 20:40:23 --> Unable to connect to the database
