<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-25 14:05:43 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-25 14:05:43 --> Unable to connect to the database
ERROR - 2015-04-25 17:22:33 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-25 17:22:33 --> Unable to connect to the database
ERROR - 2015-04-25 17:23:09 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-25 17:23:09 --> Unable to connect to the database
ERROR - 2015-04-25 17:34:06 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/kevingx91/domains/kevinroelands.be/public_html/management/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2015-04-25 17:34:06 --> Unable to connect to the database
