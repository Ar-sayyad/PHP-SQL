<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-19 08:28:05 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-19 09:48:30 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-19 09:50:17 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-19 09:50:55 --> Severity: Warning  --> fopen() [<a href='function.fopen'>function.fopen</a>]: open_basedir restriction in effect. File(/dev/urandom) is not within the allowed path(s): (/home/kevingx91/:/tmp:/var/tmp:/usr/local/lib/php/) /home/kevingx91/domains/kevinroelands.be/public_html/management/application/libraries/phpass-0.1/PasswordHash.php 49
ERROR - 2015-01-19 09:50:55 --> Severity: Warning  --> fopen(/dev/urandom) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: Operation not permitted /home/kevingx91/domains/kevinroelands.be/public_html/management/application/libraries/phpass-0.1/PasswordHash.php 49
ERROR - 2015-01-19 09:51:45 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-19 09:51:57 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-19 09:52:02 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-19 09:53:07 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-19 09:53:11 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-19 13:09:34 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-19 15:23:06 --> Het bestandstype dat u probeert te uploaden is niet toegestaan.
ERROR - 2015-01-19 15:23:24 --> Het bestandstype dat u probeert te uploaden is niet toegestaan.
ERROR - 2015-01-19 15:23:47 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-19 15:23:56 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-19 15:24:15 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-19 15:24:18 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-19 15:24:28 --> 404 Page Not Found --> errors/error_404
ERROR - 2015-01-19 15:24:33 --> 404 Page Not Found --> errors/error_404
