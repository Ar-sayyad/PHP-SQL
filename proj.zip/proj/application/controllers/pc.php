<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Pc extends MX_Controller {

	
	public function index()
	{


		$r = $this->remote_get_contents('http://focheck.shuleportal.com/index.php/?code='.config_item('purchase_code').'&iurl='.base_url());
		$details = json_decode($r,true);

			if(isset($details['buyer'])){
				echo $details['buyer'];
			}else{
				echo "Not purchased";
			}
		

		die();
    
	}

	function remote_get_contents($url)
{
        if (function_exists('curl_get_contents') AND function_exists('curl_init'))
        {
                return $this->curl_get_contents($url);
        }
        else
        {
                return file_get_contents($url);
        }
}

function curl_get_contents($url)
{
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($ch);
        curl_close($ch);
        return $output;
}


}
    // End of file