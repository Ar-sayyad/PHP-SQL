<?php

$lang['migration_none_found']			= "Er zijn geen migraties gevonden.";
$lang['migration_not_found']			= "Deze migratie kon niet gevonden worden.";
$lang['migration_multiple_version']		= "Dit zijn dezelfde migraties mer versie nummer: %d.";
$lang['migration_class_doesnt_exist']	= "De migratie class \"%s\" kon niet gevonden worden.";
$lang['migration_missing_up_method']	= "De migration class \"%s\" mist een'up' methode.";
$lang['migration_missing_down_method']	= "De migration class \"%s\" mist een 'down' methode.";
$lang['migration_invalid_filename']		= "Migratie \"%s\" heeft een ongeldig bestandsnaam.";


/* End of file migration_lang.php */
/* Location: ./system/language/english/migration_lang.php */