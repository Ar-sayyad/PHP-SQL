<?php

$lang['terabyte_abbr'] = "TB";
$lang['gigabyte_abbr'] = "GB";
$lang['megabyte_abbr'] = "MB";
$lang['kilobyte_abbr'] = "kB";
$lang['bytes'] = "Baјtovi";


/* End of file number_lang.php */
/* Location: ./system/language/croatian/number_lang.php */