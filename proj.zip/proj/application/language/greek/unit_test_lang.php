<?php
$lang['ut_test_name'] = 'Όνομα Δοκιμής';
$lang['ut_test_datatype'] = 'Τύπος Δεδομένων Δοκιμής';
$lang['ut_res_datatype'] = 'Αναμενόμενος Τύπο Δεδομένων';
$lang['ut_result'] = 'Αποτέλεσμα';
$lang['ut_undefined'] = 'Δεν έχει οριστεί όνομα δοκιμής';
$lang['ut_file'] = 'Όνομα αρχείου';
$lang['ut_line'] = 'Αριθμός γραμμής';
$lang['ut_passed'] = 'Πέρασε';
$lang['ut_failed'] = 'Απέτυχε';
$lang['ut_boolean'] = 'Boolean';
$lang['ut_integer'] = 'Ακέραιος';
$lang['ut_float'] = 'Κυλιόμενος';
$lang['ut_double'] = 'Διπλός Κυλιόμενος';
$lang['ut_string'] = 'Συμβολοσειρά';
$lang['ut_array'] = 'Πίνακας';
$lang['ut_object'] = 'Αντικείμενο';
$lang['ut_resource'] = 'Πόρος';
$lang['ut_null'] = 'Κενό';
$lang['ut_notes'] = 'Σημειώσεις';

/* End of file unit_test_lang.php */
/* Location: ./application/language/greek/unit_test_lang.php */
