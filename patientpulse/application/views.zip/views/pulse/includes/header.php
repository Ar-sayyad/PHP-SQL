<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="keywords" content="">
	<title>Patient Pulse | <?php echo $title;?></title>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700|Poppins:300,400,500,600" rel="stylesheet">
        <link rel="icon" href="<?php echo base_url();?>Theme/assets/img/patientpulse.png" type="image/x-icon">
	<link rel="stylesheet" href="<?php echo base_url();?>Theme/assets/css/vendor.bundle.css">
	<link rel="stylesheet" href="<?php echo base_url();?>Theme/assets/css/app.bundle.css">
	<link rel="stylesheet" href="<?php echo base_url();?>Theme/assets/css/theme-a.css">      
</head>
