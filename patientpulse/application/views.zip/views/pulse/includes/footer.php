<footer id="footer_wrapper">
    <div class="footer-content">
        <div class="row copy-wrapper">
          <div class="col-xs-12">
            <p class="copy">&copy; Copyright <time class="year"></time> ECGiT - All Rights Reserved</p>
          </div>
        </div>
    </div>
</footer>