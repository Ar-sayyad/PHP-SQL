<script src="<?php echo base_url();?>Theme/assets/js/vendor.bundle.js"></script>
<script src="<?php echo base_url();?>Theme/assets/js/app.bundle.js"></script>
<script src="<?php echo base_url();?>Theme/assets/js/data-table/datatables-init.js"></script>