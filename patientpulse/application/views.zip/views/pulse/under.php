<div class="row">			
        <div class="col-lg-12 col-md-12">
            <div class="card">
                <img src="<?php echo base_url();?>Theme/assets/img/img-servicesbox2.png" alt=""/>
                    <h1 style="margin-top: 20%;text-align: center">Under Development...!</h1>
            </div>
        </div>	


</div>

